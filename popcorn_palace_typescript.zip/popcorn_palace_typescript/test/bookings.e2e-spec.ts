import request from 'supertest';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import { Test, TestingModule } from '@nestjs/testing';
import { AppModule } from '../src/app.module';
import { DataSource } from 'typeorm';
import { Booking } from '../src/modules/booking/entities/booking.entity';
import { ShowtimeSeat } from '../src/modules/showtimes/entities/showtime-seat.entity';
import { Showtime } from '../src/modules/showtimes/entities/showtime.entity';
import { Movie } from '../src/modules/movies/entities/movie.entity';

describe('BookingsController (e2e)', () => {
    let app: INestApplication;
    let dataSource: DataSource;
    let showtimeId: string;
    const userId = 'test-user-id';

    beforeAll(async () => {
        const moduleFixture: TestingModule = await Test.createTestingModule({
            imports: [AppModule],
        }).compile();

        app = moduleFixture.createNestApplication();
        app.useGlobalPipes(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true, transform: true }));
        await app.init();
        dataSource = app.get(DataSource);

        // Create movie
        const movieRes = await request(app.getHttpServer())
            .post('/movies')
            .send({
                title: 'Test Movie',
                duration: 90,
                genre: 'Drama',
                rating: 7.5,
                releaseYear: 2023,
            })
            .expect(201);

        const movieId = movieRes.body.id;

        // Create showtime
        const showtimeRes = await request(app.getHttpServer())
            .post('/showtimes')
            .send({
                movieId,
                theater: 'Hall 1',
                startTime: '2025-05-01T18:00:00.000Z',
                endTime: '2025-05-01T19:30:00.000Z',
                price: 30,
            })
            .expect(201);

        showtimeId = showtimeRes.body.id;
    });

    afterAll(async () => {
        await dataSource.getRepository(Booking).delete({});
        await dataSource.getRepository(ShowtimeSeat).delete({});
        await dataSource.getRepository(Showtime).delete({});
        await dataSource.getRepository(Movie).delete({});
        await app.close();
    });

    it('should book a valid seat', async () => {
        const res = await request(app.getHttpServer())
            .post('/bookings')
            .send({
                showtimeId,
                seatNumber: 15,
                userId,
            })
            .expect(201); 

        expect(res.body.bookedSeat).toBe(15);
        expect(res.body.success).toBe(true);
    });

    it('should fail booking already booked seat', async () => {
        const res = await request(app.getHttpServer())
            .post('/bookings')
            .send({
                showtimeId,
                seatNumber: 15,
                userId,
            })
            .expect(400);
        expect(res.body.success).toBe(false);
        expect(res.body.unavailableSeat).toBe(15);
    });

    it('should fail booking for invalid showtime', async () => {
        await request(app.getHttpServer())
            .post('/bookings')
            .send({
                showtimeId: '00000000-0000-0000-0000-000000000000',
                seatNumber: 1,
                userId,
            })
            .expect(400); 
    });
});