import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BookingsService } from './bookings.service';
import { BookingsController } from './bookings.controller';
import { Booking } from './entities/booking.entity';
import { Screening } from '../screenings/entities/screening.entity';
import { Seat } from '../halls-seats/entities/seat.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Booking, Screening, Seat])],
  controllers: [BookingsController],
  providers: [BookingsService],
})
export class BookingsModule {}
