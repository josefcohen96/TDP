import { DataSource } from 'typeorm';
import { Hall } from '../modules/halls-seats/entities/hall.entity';
import { Seat } from '../modules/halls-seats/entities/seat.entity';

export const seedHallsAndSeats = async (dataSource: DataSource) => {
  const hallRepo = dataSource.getRepository(Hall);
  const seatRepo = dataSource.getRepository(Seat);

  const existing = await hallRepo.findOne({ where: { name: 'Hall 1' } });
  if (existing) {
    console.log('✅ Hall 1 already seeded');
    return;
  }

  const hall = hallRepo.create({ name: 'Hall 1', capacity: 50 });
  await hallRepo.save(hall);

  const seats: Seat[] = [];
  const rows = ['A', 'B', 'C', 'D', 'E'];

  for (const row of rows) {
    for (let number = 1; number <= 10; number++) {
      seats.push(
        seatRepo.create({
          row,
          number,
          hall,
        })
      );
    }
  }

  await seatRepo.save(seats);
  console.log('✅ Hall 1 and seats seeded');
};
